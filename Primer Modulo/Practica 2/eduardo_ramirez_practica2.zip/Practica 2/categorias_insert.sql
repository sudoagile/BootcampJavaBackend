INSERT INTO Categorias (Categoria_ID, Nombre) VALUES
(1, 'Ficción'),
(2, 'Clásicos'),
(3, 'Literatura Peruana'),
(4, 'Cuentos'),
(5, 'Ensayo');