INSERT INTO Lectores (Nombre) VALUES
('Juan'),
('María'),
('Pedro'),
('Ana'),
('Luis'),
('Laura'),
('Carlos'),
('Sofía'),
('Diego'),
('Elena');
