INSERT INTO Libros (ISBN, Título) VALUES
('978-0143039433', 'La ciudad y los perros'),
('978-0140292016', 'El mundo es ancho y ajeno'),
('978-1939765106', 'Los ríos profundos'),
('978-8423341830', 'Un mundo para Julius'),
('978-8432234961', 'Los cachorros'),
('978-8408055771', 'Redoble por Rancas'),
('978-0060883287', 'El zorro de arriba y el zorro de abajo'),
('978-6124516171', 'De la amistad al amor'),
('978-9871138682', 'Cuentos de la selva'),
('978-8483837328', 'Tradiciones peruanas');
