INSERT INTO Autores (Autor_ID, Nombre) VALUES
(1, 'Mario Vargas Llosa'),
(2, 'Ciro Alegría'),
(3, 'José María Arguedas'),
(4, 'Alfredo Bryce Echenique'),
(5, 'Julio Ramón Ribeyro'),
(6, 'Manuel Scorza'),
(7, 'Abraham Valdelomar'),
(8, 'José Carlos Mariátegui'),
(9, 'Magda Portal'),
(10, 'Enrique López Albújar');

