package com.codigo.miprimeraapig.service;

import com.codigo.miprimeraapig.entity.UsuariosEntity;

public interface UsuariosService {
    UsuariosEntity crearUsuario(UsuariosEntity usuariosEntity);
}
