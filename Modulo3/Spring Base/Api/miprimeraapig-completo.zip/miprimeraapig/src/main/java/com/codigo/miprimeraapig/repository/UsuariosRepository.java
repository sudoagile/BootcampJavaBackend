package com.codigo.miprimeraapig.repository;

import com.codigo.miprimeraapig.entity.UsuariosEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuariosRepository extends JpaRepository<UsuariosEntity, Long> {


}
