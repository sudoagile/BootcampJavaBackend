package com.codigo.miprimeraapig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiprimeraapigApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiprimeraapigApplication.class, args);
	}

}
